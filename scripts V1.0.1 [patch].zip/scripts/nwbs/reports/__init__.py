'''
Reports - Module

Usage - Contains a view class to manage the functions partaining to reports of 
        of previous reports created
'''